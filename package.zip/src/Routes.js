import React from 'react'

const Routes = () => {
  return (
    <div>Routes</div>
  )
}

export default Routes